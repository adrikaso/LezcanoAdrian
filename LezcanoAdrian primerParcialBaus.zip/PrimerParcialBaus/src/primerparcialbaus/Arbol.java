package primerparcialbaus;

/**
 *
 * @author adri pc
 */
public class Arbol extends Planta implements PuedePodar{
    private int  alturaMaxima;

    public Arbol(String nombre, String ubicacion, String clima, int alturaMaxima) {
        super(nombre, ubicacion, clima);
        this.alturaMaxima = alturaMaxima;
    }

    @Override
    public String toString() {
        return "Arbol = " + "nombre: " + super.nombre + ", ubicacion: " + super.ubicacion + ", clima" + super.clima + ", alturaMaxima: " + alturaMaxima;
    }

    @Override
    public void podar() {
        System.out.println("Podando Arbol...");
    }
    
    
    
    
}
