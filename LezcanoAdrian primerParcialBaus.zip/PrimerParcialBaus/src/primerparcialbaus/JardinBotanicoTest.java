package primerparcialbaus;

public class JardinBotanicoTest {

    public static void main(String[] args) {

        JardinBotanico jardin = new JardinBotanico();

        try {
            jardin.agregarPlanta(new Flor("Clavel", "Bajo techo", "Frio", TempFlorecimiento.INVIERNO));
            jardin.agregarPlanta(new Arbusto("Coralillo", "Aire libre", "Templado", 10));
            jardin.agregarPlanta(new Arbol("Roble", "Zona Norte Jardin", "Calido", 10));
            jardin.agregarPlanta(new Arbol("Roble", "Zona Norte Jardin", "Calido", 10));

        } catch (IllegalArgumentException e) {
            System.out.println(e.getMessage());
        } catch (PlantaRepetidaException p){
            System.out.println(p.getMessage());
        } catch (NullPointerException e){
            System.out.println(e.getMessage());
        }

        jardin.mostrarPlantas();
        jardin.podarPlantas();
    }
}
