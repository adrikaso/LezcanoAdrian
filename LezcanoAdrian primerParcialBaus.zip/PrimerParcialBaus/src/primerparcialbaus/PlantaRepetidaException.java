package primerparcialbaus;

/**
 *
 * @author adri pc
 */
public class PlantaRepetidaException extends RuntimeException{
    public static final String MESSAGE = "Error: No se admiten plantas repetidas, hay una planta identica con el mismo nombre como tambien, misma ubicacion.";

    public PlantaRepetidaException() {
        super(MESSAGE);
    }
}
