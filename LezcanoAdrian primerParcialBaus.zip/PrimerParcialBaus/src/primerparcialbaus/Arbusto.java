package primerparcialbaus;

/**
 *
 * @author adri pc
 */
public class Arbusto extends Planta implements PuedePodar{
    private int densidadFollaje;
    private final int DENSIDAD_MIN = 1;
    private final int DENSIDAD_MAX = 10;
    
    
    public Arbusto(String nombre, String ubicacion, String clima, int densidadFollaje) {
        super(nombre, ubicacion, clima);
        this.densidadFollaje = validarDensidad(densidadFollaje);
    }

    
    private int validarDensidad(int densidad){
        if( densidad < DENSIDAD_MIN || densidad > DENSIDAD_MAX){
            throw new IllegalArgumentException("En Arbusto solo se permite una altura entre 1 y 10");
        }
        return densidad;
    }

    @Override
    public String toString() {
        return "Arbusto = " + "nombre: " + super.nombre + ", ubicacion: " + super.ubicacion + ", clima" + super.clima  + ", densidadFollaje: " + densidadFollaje + ", ALTURA_MIN: " + DENSIDAD_MIN + ", ALTURA_MAX: " + DENSIDAD_MAX;
    }
    
    
    
    @Override
    public void podar() {
        System.out.println("Podando Arbusto...");
    }
    
    
    
}
