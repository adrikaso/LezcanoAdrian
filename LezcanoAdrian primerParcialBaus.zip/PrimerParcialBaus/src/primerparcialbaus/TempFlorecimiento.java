package primerparcialbaus;

/**
 *
 * @author adri pc
 */
public enum TempFlorecimiento {
    PRIMAVERA,
    VERANO,
    OTONIO,
    INVIERNO;
}
