package primerparcialbaus;

/**
 *
 * @author adri pc
 */
public class Flor extends Planta {
    TempFlorecimiento temporada;

    public Flor(String nombre, String ubicacion, String clima, TempFlorecimiento temporada) {
        super(nombre, ubicacion, clima);
        this.temporada = temporada;
    }

    @Override
    public String toString() {
        return "Flor = " + "nombre: " + super.nombre + ", ubicacion: " + super.ubicacion + ", clima" + super.clima + ", temporada: " + temporada + '}';
    }
    
    
    
}
