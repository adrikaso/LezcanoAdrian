package primerparcialbaus;

import java.util.Objects;

/**
 *
 * @author adri pc
 */
public abstract class Planta {
    //Acá uso protected para evitar usar getters para los toString en los hijos, tengo dudas sobre esto pero para mí esta bien.
    protected String nombre;
    protected String ubicacion;
    protected String clima;

    public Planta(String nombre, String ubicacion, String clima) {
        this.nombre = nombre;
        this.ubicacion = ubicacion;
        this.clima = clima;
    }
    
    
    @Override
    public boolean equals(Object o){
        if(this == o){
            return true;
        }
        if(o == null || getClass() != o.getClass()){
            return false;
        }
        Planta other = (Planta) o;

        return other.nombre.equals(this.nombre) &&
                other.ubicacion.equals(this.ubicacion);
    }

    @Override
    public int hashCode() {
        return Objects.hash(nombre, ubicacion);
    }

    @Override
    public String toString() {
        return "Planta = " + "nombre: " + nombre + ", ubicacion: " + ubicacion + ", clima: " + clima;
    }

    
    
    
}
