/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package primerparcialbaus;

import java.util.ArrayList;

public class JardinBotanico {
    private ArrayList<Planta> plantas;
    
    
    public JardinBotanico() {
        plantas = new ArrayList<>();
    }
    
    public void agregarPlanta(Planta planta){
        if(planta == null){
            throw new NullPointerException("No se admiten null como planta.");
        }
        
        if(plantas.contains(planta)){
            throw new PlantaRepetidaException();
        }
        
        plantas.add(planta);
        
    }
    
    public void mostrarPlantas(){
        if(plantas.isEmpty()){
            System.out.println("El jardín está vacío");
        }else{
            for(Planta planta : plantas){
                System.out.println(planta);
            }
        }
    }
    
    public void podarPlantas() {
        for (Planta p : plantas) {
            if (p instanceof PuedePodar pP) {
                pP.podar();
            } else{
                System.out.println("La flor no requiere poda.");
            }
        }
    }
    
}
