package primerparcialbaus;

public interface PuedePodar {
    void podar();
}
